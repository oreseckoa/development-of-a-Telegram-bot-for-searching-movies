import pymysql

def connect():
    """Подключается к базе данных и возвращает соединение, либо None в случае ошибки."""
    try:
        # Пытаемся установить соединение с базой данных
        conn = pymysql.connect(
            host='ich-edit.edu.itcareerhub.de',
            user='ich1',
            password='ich1_password_ilovedbs',
            database='170624_Oreshechko'
        )
        print("Соединение с базой данных успешно установлено!")  # Успешное соединение
        return conn
    except pymysql.MySQLError as e:
        # Обрабатываем ошибки подключения
        print(f"Ошибка при подключении к базе данных: {e}")
        return None

def close_connection(conn):
    """Закрывает соединение с базой данных."""
    if conn:  # Проверяем, что соединение установлено
        try:
            conn.close()
            print("Соединение с базой данных успешно закрыто.")  # Успешное закрытие соединения
        except pymysql.MySQLError as e:
            # Обрабатываем ошибки при закрытии соединения
            print(f"Ошибка при закрытии соединения: {e}")

# Основной блок программы
if __name__ == "__main__":
    # Подключаемся к базе данных
    conn = connect()

    # Закрываем соединение (если оно было установлено)
    close_connection(conn)