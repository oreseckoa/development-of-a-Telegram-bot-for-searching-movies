from db_connect import connect
from movies_app import (
    search_movies,
    get_popular_searches,
    get_genres,
    get_years,
    highlight_keyword,
    format_results,
)
from colorama import Fore, init
from tabulate import tabulate

init(autoreset=True)


def main():
    conn = connect()

    try:
        while True:
            print(Fore.GREEN + "\n🎥 Меню:")
            print("1. 🔍 Поиск фильмов")
            print("2. 📊 Показать популярные запросы")
            print("3. ❌ Выход")
            choice = input(Fore.CYAN + "🚀 Выберите действие (введите 1, 2 или 3): ")

            if choice == "1":
                genres = get_genres(conn)
                print(Fore.GREEN + "\n🎭 Доступные жанры:")
                for idx, genre in enumerate(genres, 1):
                    print(f"  {idx}. {genre}")

                genre_choice = input(Fore.CYAN + "🎯 Выберите жанр (введите номер): ")
                genre = genres[int(genre_choice) - 1] if genre_choice.isdigit() else None

                years = get_years(conn)
                print(Fore.GREEN + "\n📅 Доступные годы:")
                print(", ".join(map(str, years)))

                year_choice = input(Fore.CYAN + "🕒 Введите год (или оставьте пустым): ")
                year = int(year_choice) if year_choice.isdigit() else None

                keyword = input(Fore.CYAN + "🔑 Введите ключевое слово: ")

                results = search_movies(conn, keyword=keyword, year=year, genre=genre, limit=10)

                if results:
                    formatted_results = format_results(results, keyword)
                    print(Fore.GREEN + "\n🎬 Найденные фильмы:")
                    print(
                        tabulate(
                            formatted_results,
                            headers=[
                                "Название",
                                "Описание",
                                "Год",
                                "Жанры",
                                "Длительность",
                                "Рейтинг"
                            ],
                            tablefmt="fancy_grid",  # Используем стиль с рамками
                            numalign="center",  # Центрируем числа
                            stralign="center",  # Центрируем текст
                        )
                    )
                else:
                    print(Fore.RED + "❌ Фильмы по заданным параметрам не найдены.")

            elif choice == "2":
                popular_searches = get_popular_searches(conn)
                if popular_searches:
                    print(Fore.GREEN + "\n🔥 Популярные запросы:")
                    for search in popular_searches:
                        keyword, year, genre, search_count = search
                        print(
                            f"🔑 {Fore.CYAN}Ключевое слово: {keyword}, "
                            f"📅 Год: {year}, 🎭 Жанр: {genre}, "
                            f"📊 {Fore.MAGENTA}Количество запросов: {search_count}"
                        )
                else:
                    print(Fore.RED + "❌ Популярных запросов пока нет.")

            elif choice == "3":
                print(Fore.GREEN + "👋 Спасибо за использование программы! Выход.")
                break
            else:
                print(Fore.RED + "⚠️ Неверный выбор, попробуйте снова.")

    finally:
        conn.close()


if __name__ == "__main__":
    main()