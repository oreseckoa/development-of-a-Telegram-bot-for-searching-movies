from tqdm import tqdm
import re
from textwrap import wrap



select_movies = """SELECT title, plot, year, genres, runtime, `imdb.rating` FROM movies"""

def highlight_keyword(text, keyword):
    """Подсветка ключевого слова в тексте."""
    if keyword:
        return re.sub(f"(?i)({re.escape(keyword)})", r"\033[1;31m\1\033[0m", text)
    return text

def format_results(results, keyword):
    """Форматирует результаты поиска для вывода в таблицу."""
    formatted_results = []
    for movie in results:
        title = highlight_keyword(movie[0], keyword)
        plot = "\n".join(wrap(highlight_keyword(movie[1], keyword), width=40))  # Перенос строк для описания
        year = str(movie[2])
        genres = "\n".join(wrap(movie[3], width=15))  # Перенос строк для жанров
        runtime = f"{movie[4]} минут"
        rating = f"{movie[5]:.1f}" if movie[5] else "N/A"  # Рейтинг с одной цифрой после точки
        formatted_results.append([title, plot, year, genres, runtime, rating])
    return formatted_results

def log_search(conn, keyword=None, year=None, genre=None):
    """Логирование поискового запроса."""
    cursor = conn.cursor()
    query = "SELECT id, search_count FROM search_logs WHERE keyword = %s AND year = %s AND genre = %s"
    cursor.execute(query, (keyword, year, genre))
    result = cursor.fetchone()

    if result:
        update_query = "UPDATE search_logs SET search_count = search_count + 1 WHERE id = %s"
        cursor.execute(update_query, (result[0],))
    else:
        insert_query = "INSERT INTO search_logs (keyword, year, genre, search_count) VALUES (%s, %s, %s, 1)"
        cursor.execute(insert_query, (keyword, year, genre))

    conn.commit()
    cursor.close()

def get_genres(conn):

    query = "SELECT DISTINCT genres FROM movies"
    with conn.cursor() as cursor:
        cursor.execute(query)
        genres = set()
        for row in cursor.fetchall():
            for genre in row[0].split(","):
                genres.add(genre.strip())
    return sorted(genres)

def get_years(conn):
    """Получение списка уникальных годов."""
    cursor = conn.cursor()
    query = "SELECT DISTINCT year FROM movies ORDER BY year"
    cursor.execute(query)
    years = [row[0] for row in cursor.fetchall()]
    cursor.close()
    return years

def search_movies(conn, keyword=None, year=None, genre=None, limit=10):
    """Поиск фильмов с параметрами."""
    query = select_movies
    conditions = []
    params = []

    if keyword:
        conditions.append("(title LIKE %s OR plot LIKE %s)")
        keyword_param = f"%{keyword}%"
        params.extend([keyword_param, keyword_param])

    if year:
        conditions.append("year = %s")
        params.append(year)

    if genre:
        conditions.append("genres LIKE %s")
        genre_param = f"%{genre}%"
        params.append(genre_param)

    if conditions:
        query += " WHERE " + " AND ".join(conditions)

    query += f" LIMIT {limit}"

    cursor = conn.cursor()
    cursor.execute(query, tuple(params))
    result = cursor.fetchall()
    cursor.close()

    log_search(conn, keyword, year, genre)

    for _ in tqdm(result, desc="Поиск фильмов"):
        pass

    return result

def get_popular_searches(conn, limit=5):
    """Получение популярных запросов."""
    cursor = conn.cursor()
    query = "SELECT keyword, year, genre, search_count FROM search_logs ORDER BY search_count DESC LIMIT %s"
    cursor.execute(query, (limit,))
    result = cursor.fetchall()
    cursor.close()
    return result