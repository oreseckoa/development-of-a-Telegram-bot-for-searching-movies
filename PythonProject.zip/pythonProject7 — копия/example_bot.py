import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
from db_connect import connect
from movies_app import (
    search_movies,
    get_popular_searches,
    get_years,
    get_genres
)

API_TOKEN = '7034867962:AAEQbX88dDFpmKWwwB5iawvRz4UnrdHmtNI'

bot = telebot.TeleBot(API_TOKEN)


# Функция логирования запросов
def log_search(conn, keyword=None, year=None, genre=None):
    """Логирование поискового запроса."""
    cursor = conn.cursor()
    query = "SELECT id, search_count FROM search_logs WHERE keyword = %s AND year = %s AND genre = %s"
    cursor.execute(query, (keyword, year, genre))
    result = cursor.fetchone()

    if result:
        update_query = "UPDATE search_logs SET search_count = search_count + 1 WHERE id = %s"
        cursor.execute(update_query, (result[0],))
    else:
        insert_query = "INSERT INTO search_logs (keyword, year, genre, search_count) VALUES (%s, %s, %s, 1)"
        cursor.execute(insert_query, (keyword, year, genre))

    conn.commit()
    cursor.close()


# Создание кнопок для главного меню
def main_menu():
    markup = ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    year_btn = KeyboardButton('📅 Поиск по году')
    genre_btn = KeyboardButton('🎭 Поиск по жанру')
    genre_and_year_btn = KeyboardButton('🎬 Жанр и год')
    keyword_btn = KeyboardButton('🔍 Поиск по ключевому слову')
    popular_btn = KeyboardButton('🔥 Популярные запросы')
    markup.add(year_btn, genre_btn, genre_and_year_btn, keyword_btn, popular_btn)
    return markup


@bot.message_handler(commands=['start'])
def start_command(message):
    bot.send_message(
        message.chat.id,
        (
            "Привет! Я помогу вам найти фильмы и показать популярные запросы.\n"
            "Вот список доступных команд на кнопках ниже:"
        ),
        reply_markup=main_menu()
    )


@bot.message_handler(func=lambda message: message.text == '📅 Поиск по году')
def year_command(message):
    conn = connect()
    years = get_years(conn)
    conn.close()
    markup = ReplyKeyboardMarkup(row_width=3, resize_keyboard=True)
    for year in years:
        markup.add(KeyboardButton(f'📅 {year}'))
    bot.send_message(message.chat.id, "Выберите год из доступных:", reply_markup=markup)
    bot.register_next_step_handler(message, year_movies_handler)


def year_movies_handler(message):
    year = message.text.strip('📅 ')
    conn = connect()
    results = search_movies(conn, year=int(year), limit=10)
    log_search(conn, year=int(year))
    conn.close()

    if results:
        response = "Найденные фильмы:\n"
        for movie in results:
            title, plot, year, genres, runtime, rating = movie
            response += (f"\nНазвание: {title}\nОписание: {plot}\nГод: {year}\nЖанры: {genres}\n"
                         f"Длительность: {runtime} минут\nРейтинг IMDb: {rating}\n")
    else:
        response = "Фильмы по заданному году не найдены."

    bot.send_message(message.chat.id, response, reply_markup=main_menu())


@bot.message_handler(func=lambda message: message.text == '🎭 Поиск по жанру')
def genre_command(message):
    conn = connect()
    genres = get_genres(conn)
    conn.close()
    markup = ReplyKeyboardMarkup(row_width=3, resize_keyboard=True)
    for genre in genres:
        markup.add(KeyboardButton(f'🎭 {genre}'))
    bot.send_message(message.chat.id, "Выберите жанр из доступных:", reply_markup=markup)
    bot.register_next_step_handler(message, genre_movies_handler)


def genre_movies_handler(message):
    genre = message.text.strip('🎭 ')
    conn = connect()
    results = search_movies(conn, genre=genre, limit=10)
    log_search(conn, genre=genre)
    conn.close()

    if results:
        response = "Найденные фильмы:\n"
        for movie in results:
            title, plot, year, genres, runtime, rating = movie
            response += (f"\nНазвание: {title}\nОписание: {plot}\nГод: {year}\nЖанры: {genres}\n"
                         f"Длительность: {runtime} минут\nРейтинг IMDb: {rating}\n")
    else:
        response = "Фильмы по заданному жанру не найдены."

    bot.send_message(message.chat.id, response, reply_markup=main_menu())


@bot.message_handler(func=lambda message: message.text == '🎬 Жанр и год')
def genre_and_year_command(message):
    conn = connect()
    genres = get_genres(conn)
    conn.close()
    markup = ReplyKeyboardMarkup(row_width=3, resize_keyboard=True)
    for genre in genres:
        markup.add(KeyboardButton(f'🎭 {genre}'))
    bot.send_message(message.chat.id, "Выберите жанр из доступных:", reply_markup=markup)
    bot.register_next_step_handler(message, genre_year_handler_step_1)


def genre_year_handler_step_1(message):
    genre = message.text.strip('🎭 ')
    conn = connect()
    years = get_years(conn)
    conn.close()
    message_genre = genre
    markup = ReplyKeyboardMarkup(row_width=3, resize_keyboard=True)
    for year in years:
        markup.add(KeyboardButton(f'📅 {year}'))
    bot.send_message(message.chat.id, "Выберите год из доступных:", reply_markup=markup)
    bot.register_next_step_handler(message, genre_year_handler_step_2, message_genre)


def genre_year_handler_step_2(message, genre):
    year = message.text.strip('📅 ')
    conn = connect()
    results = search_movies(conn, genre=genre, year=int(year), limit=10)
    log_search(conn, genre=genre, year=int(year))
    conn.close()

    if results:
        response = "Найденные фильмы:\n"
        for movie in results:
            title, plot, year, genres, runtime, rating = movie
            response += (f"\nНазвание: {title}\nОписание: {plot}\nГод: {year}\nЖанры: {genres}\n"
                         f"Длительность: {runtime} минут\nРейтинг IMDb: {rating}\n")
    else:
        response = "Фильмы по заданным жанру и году не найдены."

    bot.send_message(message.chat.id, response, reply_markup=main_menu())


@bot.message_handler(func=lambda message: message.text == '🔍 Поиск по ключевому слову')
def keyword_command(message):
    bot.send_message(message.chat.id, 'Введите ключевое слово для поиска:',
                     reply_markup=ReplyKeyboardMarkup(resize_keyboard=True).add(KeyboardButton('Отмена')))
    bot.register_next_step_handler(message, search_movies_handler)


def search_movies_handler(message):
    keyword = message.text
    if keyword.lower() == 'отмена':
        bot.send_message(message.chat.id, 'Поиск отменен', reply_markup=main_menu())
        return
    conn = connect()
    results = search_movies(conn, keyword=keyword, limit=10)
    log_search(conn, keyword=keyword)
    conn.close()

    if results:
        response = "Найденные фильмы:\n"
        for movie in results:
            title, plot, year, genres, runtime, rating = movie
            response += (f"\nНазвание: {title}\nОписание: {plot}\nГод: {year}\nЖанры: {genres}\n"
                         f"Длительность: {runtime} минут\nРейтинг IMDb: {rating}\n")
    else:
        response = "Фильмы по заданному ключевому слову не найдены."

    bot.send_message(message.chat.id, response, reply_markup=main_menu())


@bot.message_handler(func=lambda message: message.text == '🔥 Популярные запросы')
def popular_command(message):
    conn = connect()
    popular_searches = get_popular_searches(conn)
    conn.close()

    if popular_searches:
        response = "Популярные запросы:\n"
        for search in popular_searches:
            keyword, year, genre, search_count = search
            response += (
                f"Ключевое слово: {keyword}, Год: {year}, Жанр: {genre}, Количество запросов: {search_count}\n"
            )
    else:
        response = "Популярных запросов пока нет."

    bot.send_message(message.chat.id, response, reply_markup=main_menu())


bot.infinity_polling()
